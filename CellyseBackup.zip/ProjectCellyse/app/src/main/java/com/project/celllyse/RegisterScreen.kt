package com.project.celllyse

import androidx.appcompat.app.AppCompatActivity

public class RegisterScreen : AppCompatActivity() {
    public override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.register_screen)
    }
}
